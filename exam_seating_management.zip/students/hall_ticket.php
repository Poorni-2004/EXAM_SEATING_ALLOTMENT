<?php
session_start();
require('../fpdf.php');
include "../db.php";

$id = $_SESSION['loginid'];

$result = mysqli_query($conn, "
    SELECT s.name, s.rollno, c.year, c.dept, c.division, b.room_id, r.room_no, r.floor
    FROM students s
    JOIN class c ON s.class = c.class_id
    JOIN batch b ON s.class = b.class_id AND s.rollno BETWEEN b.startno AND b.endno
    JOIN room r ON b.room_id = r.rid
    WHERE s.student_id = $id
");

$data = mysqli_fetch_assoc($result);

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',14);
$pdf->Cell(0,10,'Exam Hall Ticket',0,1,'C');
$pdf->Ln(10);

$pdf->SetFont('Arial','',12);
$pdf->Cell(0,10,"Name: {$data['name']}",0,1);
$pdf->Cell(0,10,"Roll No: {$data['rollno']}",0,1);
$pdf->Cell(0,10,"Class: {$data['year']} {$data['dept']} {$data['division']}",0,1);
$pdf->Cell(0,10,"Room No: {$data['room_no']} (Floor {$data['floor']})",0,1);
$pdf->Output();
?>
