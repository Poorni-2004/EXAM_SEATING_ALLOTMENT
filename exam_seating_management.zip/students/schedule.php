<?php
session_start();
include "../db.php";

if (!isset($_SESSION['loginid'])) {
    header("Location: ../login_student.php");
    exit;
}

$student_id = $_SESSION['loginid'];

$result = mysqli_query($conn, "
    SELECT es.subject, es.exam_date, es.exam_time, r.room_no, es.seat_number
    FROM exam_schedule es
    JOIN room r ON es.room_id = r.rid
    WHERE es.student_id = $student_id
    ORDER BY es.exam_date
");

echo "<h2>📅 Your Exam Schedule</h2><table class='table table-bordered'>";
echo "<tr><th>Subject</th><th>Date</th><th>Time</th><th>Room</th><th>Seat</th></tr>";

while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>
            <td>{$row['subject']}</td>
            <td>{$row['exam_date']}</td>
            <td>{$row['exam_time']}</td>
            <td>{$row['room_no']}</td>
            <td>{$row['seat_number']}</td>
          </tr>";
}
echo "</table>";
?>
