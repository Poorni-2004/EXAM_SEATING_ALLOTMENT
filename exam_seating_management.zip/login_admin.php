<?php
session_start();
include "db.php";

if (isset($_POST['submit'])) {
    $name = mysqli_real_escape_string($conn, htmlentities($_POST['name']));
    $password = mysqli_real_escape_string($conn, htmlentities($_POST['password']));

    $query = "SELECT name, password FROM admin WHERE name='$name' AND password='$password'";
    $result = mysqli_query($conn, $query);
    if (mysqli_num_rows($result) > 0) {
        $_SESSION['login'] = "admin";
        header('Location: admin/dashboard.php');
    } else {
        $_SESSION['loginmsg'] = "Incorrect Credentials";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            margin: 0;
            background: #f5f8ff;
            font-family: 'Segoe UI', sans-serif;
        }
        .login-wrapper {
            display: flex;
            min-height: 100vh;
        }
        .login-left {
            background: linear-gradient(to bottom right, #0d6efd, #0040c1);
            color: white;
            flex: 1;
            padding: 60px 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        .login-left h1 {
            font-size: 36px;
            font-weight: bold;
        }
        .login-left p {
            margin-top: 20px;
            font-size: 16px;
            line-height: 1.6;
        }
        .login-right {
            flex: 1;
            background: white;
            padding: 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        .login-box {
            max-width: 400px;
            margin: auto;
            width: 100%;
        }
        .form-control {
            height: 45px;
        }
        .btn-login {
            height: 45px;
            background-color: #0d6efd;
            border: none;
        }
        .btn-login:hover {
            background-color: #0040c1;
        }
        .loginmsg {
            color: red;
            text-align: center;
            margin-bottom: 15px;
        }
        .link {
            font-size: 0.9rem;
        }
    </style>
</head>
<body>

<div class="login-wrapper">
    <!-- Left Welcome Section -->
    <div class="login-left">
        <h1>Welcome</h1>
        <p>Welcome to the Exam Hall Seating Arrangement Portal. Please log in with your Admin credentials to manage exam schedules, rooms, and seating plans.</p>
    </div>

    <!-- Right Login Form Section -->
    <div class="login-right">
        <div class="login-box">
            <h3 class="mb-4 text-center font-weight-bold">Admin Login</h3>
            <?php if (isset($_SESSION['loginmsg'])): ?>
                <div class="loginmsg"><?php echo $_SESSION['loginmsg']; unset($_SESSION['loginmsg']); ?></div>
            <?php endif; ?>
            <form method="POST">
                <div class="form-group">
                    <label>Username</label>
                    <input type="text" name="name" class="form-control" placeholder="Enter username" required>
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Enter password" required>
                </div>
                <button type="submit" name="submit" class="btn btn-primary btn-login btn-block">Sign in</button>
            </form>
            <p class="text-center mt-3 link">Are you a student? <a href="login_student.php">Login here</a></p>
        </div>
    </div>
</div>

</body>
</html>
