<?php
$host = '127.0.0.1'; // DO NOT use 'localhost'
$user = 'root';
$password = ''; // Empty if you're not using a password
$database = 'seating'; // Make sure this DB exists
$port = 3308;

$conn = mysqli_connect($host, $user, $password, $database, $port);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
