<?php
include '../db.php';

$room_id = $_GET['room'] ?? 11;

// Fetch students in this room
$result = mysqli_query($conn, "
SELECT s.name, s.rollno, a.status
FROM students s
JOIN batch b ON s.class = b.class_id AND s.rollno BETWEEN b.startno AND b.endno
LEFT JOIN attendance a ON s.student_id = a.student_id AND b.room_id = a.room_id
WHERE b.room_id = $room_id
ORDER BY s.rollno
");

$seats = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Seating Map - Room <?= $room_id ?></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
    <style>
        .seat {
            padding: 15px;
            border-radius: 8px;
            text-align: center;
            color: white;
            font-weight: bold;
        }
        .present {
            background-color: #28a745;
        }
        .absent {
            background-color: #dc3545;
        }
        .not-marked {
            background-color: #6c757d;
        }
    </style>
</head>
<body class="p-4">
    <h3 class="mb-4">🪑 Seating Map - Room <?= $room_id ?></h3>
    <div class="container">
        <div class="row">
            <?php foreach ($seats as $seat): 
                $statusClass = $seat['status'] === 'Present' ? 'present' :
                               ($seat['status'] === 'Absent' ? 'absent' : 'not-marked');
            ?>
            <div class="col-md-2 col-sm-3 col-4 mb-3">
                <div class="seat <?= $statusClass ?>">
                    Roll: <?= $seat['rollno'] ?><br>
                    <?= $seat['name'] ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>
