<?php
include '../db.php';
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="attendance.csv"');

$output = fopen("php://output", "w");
fputcsv($output, ['Student Name', 'Roll No', 'Room No', 'Status', 'Date']);

$query = "
SELECT s.name, s.rollno, r.room_no, a.status, a.date
FROM attendance a
JOIN students s ON a.student_id = s.student_id
JOIN room r ON a.room_id = r.rid
";

$result = mysqli_query($conn, $query);
while ($row = mysqli_fetch_assoc($result)) {
    fputcsv($output, $row);
}
fclose($output);
exit;
?>
