<?php
include '../db.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['attendance'])) {
    foreach ($_POST['attendance'] as $student_id => $status) {
        $room_id = $_POST['room_id'][$student_id];
        $check = mysqli_query($conn, "SELECT * FROM attendance WHERE student_id=$student_id AND room_id=$room_id");
        if (mysqli_num_rows($check) > 0) {
            mysqli_query($conn, "UPDATE attendance SET status='$status' WHERE student_id=$student_id AND room_id=$room_id");
        } else {
            mysqli_query($conn, "INSERT INTO attendance (student_id, room_id, status) VALUES ($student_id, $room_id, '$status')");
        }
    }
    $_SESSION['attmsg'] = "Attendance updated.";
}

$result = mysqli_query($conn, "
    SELECT s.student_id, s.name, s.rollno, b.room_id, r.room_no
    FROM students s
    JOIN batch b ON s.class = b.class_id AND s.rollno BETWEEN b.startno AND b.endno
    JOIN room r ON b.room_id = r.rid
");

echo "<form method='post'><table class='table'>";
echo "<tr><th>Student</th><th>Room</th><th>Status</th></tr>";
while ($row = mysqli_fetch_assoc($result)) {
    $sid = $row['student_id'];
    $rid = $row['room_id'];
    echo "<tr>
        <td>{$row['name']} (Roll: {$row['rollno']})</td>
        <td>Room {$row['room_no']}</td>
        <td>
            <select name='attendance[$sid]'>
                <option value='Present'>Present</option>
                <option value='Absent'>Absent</option>
            </select>
            <input type='hidden' name='room_id[$sid]' value='$rid'>
        </td>
    </tr>";
}
echo "</table><button class='btn btn-primary'>Submit Attendance</button></form>";

if (isset($_SESSION['attmsg'])) {
    echo "<div class='alert alert-success'>{$_SESSION['attmsg']}</div>";
    unset($_SESSION['attmsg']);
}
?>
